-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 18, 2023 at 03:18 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_moora`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_alternatif`
--

CREATE TABLE `tb_alternatif` (
  `id_moora` int(10) NOT NULL,
  `kode_alternatif` varchar(10) NOT NULL,
  `nama_alternatif` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_alternatif`
--

INSERT INTO `tb_alternatif` (`id_moora`, `kode_alternatif`, `nama_alternatif`) VALUES
(1, 'A01', 'Dayat'),
(2, 'A02', 'Parman'),
(3, 'A03', 'Andi'),
(4, 'A04', 'Sapto'),
(5, 'A05', 'Rudi');

-- --------------------------------------------------------

--
-- Table structure for table `tb_data_kriteria`
--

CREATE TABLE `tb_data_kriteria` (
  `id_data_kriteria` int(11) NOT NULL,
  `kode_kriteria` varchar(11) NOT NULL,
  `nama_kriteria` varchar(50) NOT NULL,
  `label` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_general_ci;

--
-- Dumping data for table `tb_data_kriteria`
--

INSERT INTO `tb_data_kriteria` (`id_data_kriteria`, `kode_kriteria`, `nama_kriteria`, `label`) VALUES
(1, 'C01', 'Pekerjaan', 'benefit'),
(2, 'C02', 'Kondisi tempat tinggal', 'cost'),
(3, 'C03', 'Pendapatan Bulanan', 'benefit'),
(4, 'C04', 'Jumlah Tanggungan Anak', 'benefit');

-- --------------------------------------------------------

--
-- Table structure for table `tb_hasil_alternatif`
--

CREATE TABLE `tb_hasil_alternatif` (
  `id_hasil_alternatif` int(11) NOT NULL,
  `kode1` varchar(20) NOT NULL,
  `kode2` varchar(20) NOT NULL,
  `kode3` varchar(20) NOT NULL,
  `nilai` double(10,3) NOT NULL,
  `pow` double(10,3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_general_ci;

--
-- Dumping data for table `tb_hasil_alternatif`
--

INSERT INTO `tb_hasil_alternatif` (`id_hasil_alternatif`, `kode1`, `kode2`, `kode3`, `nilai`, `pow`) VALUES
(1, 'A01', 'C01', 'C01A01', 20.000, 0.040),
(2, 'A01', 'C02', 'C02A01', 10.000, 0.010),
(3, 'A01', 'C03', 'C03A01', 30.000, 0.090),
(4, 'A01', 'C04', 'C04A01', 10.000, 0.010),
(5, 'A01', 'C05', 'C05A01', 20.000, 0.040),
(6, 'A02', 'C01', 'C01A02', 20.000, 0.040),
(7, 'A02', 'C02', 'C02A02', 10.000, 0.010),
(8, 'A02', 'C03', 'C03A02', 30.000, 0.090),
(9, 'A02', 'C04', 'C04A02', 30.000, 0.090),
(10, 'A02', 'C05', 'C05A02', 20.000, 0.040),
(11, 'A03', 'C01', 'C01A03', 30.000, 0.090),
(12, 'A03', 'C02', 'C02A03', 40.000, 0.160),
(13, 'A03', 'C03', 'C03A03', 30.000, 0.090),
(14, 'A03', 'C04', 'C04A03', 10.000, 0.010),
(15, 'A03', 'C05', 'C05A03', 30.000, 0.090),
(16, 'A04', 'C01', 'C01A04', 10.000, 0.010),
(17, 'A04', 'C02', 'C02A04', 20.000, 0.040),
(18, 'A04', 'C03', 'C03A04', 10.000, 0.010),
(19, 'A04', 'C04', 'C04A04', 20.000, 0.040),
(20, 'A04', 'C05', 'C05A04', 40.000, 0.160),
(21, 'A05', 'C01', 'C01A05', 10.000, 0.010),
(22, 'A05', 'C02', 'C02A05', 30.000, 0.090),
(23, 'A05', 'C03', 'C03A05', 30.000, 0.090),
(24, 'A05', 'C04', 'C04A05', 30.000, 0.090),
(25, 'A05', 'C05', 'C05A05', 40.000, 0.160),
(26, 'A06', 'C01', 'C01A06', 10.000, 0.010),
(27, 'A06', 'C02', 'C02A06', 20.000, 0.040),
(28, 'A06', 'C03', 'C03A06', 10.000, 0.010),
(29, 'A06', 'C04', 'C04A06', 10.000, 0.010),
(30, 'A06', 'C05', 'C05A06', 30.000, 0.090);

-- --------------------------------------------------------

--
-- Table structure for table `tb_hasil_kriteria`
--

CREATE TABLE `tb_hasil_kriteria` (
  `id_hasil_kriteria` int(11) NOT NULL,
  `kode1` varchar(20) NOT NULL,
  `kode2` varchar(20) NOT NULL,
  `kode3` varchar(20) NOT NULL,
  `perbandingan_id` double(10,3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_general_ci;

--
-- Dumping data for table `tb_hasil_kriteria`
--

INSERT INTO `tb_hasil_kriteria` (`id_hasil_kriteria`, `kode1`, `kode2`, `kode3`, `perbandingan_id`) VALUES
(1, 'C01', 'C01', 'C01C01', 1.000),
(2, 'C01', 'C02', 'C01C02', 1.000),
(3, 'C01', 'C03', 'C01C03', 1.000),
(4, 'C01', 'C04', 'C01C04', 5.000),
(5, 'C02', 'C02', 'C02C02', 1.000),
(6, 'C02', 'C03', 'C02C03', 5.000),
(7, 'C02', 'C04', 'C02C04', 5.000),
(8, 'C03', 'C03', 'C03C03', 1.000),
(9, 'C03', 'C04', 'C03C04', 5.000),
(10, 'C04', 'C04', 'C04C04', 1.000),
(11, 'C01', 'C01', 'C01C01', 1.000),
(12, 'C02', 'C01', 'C02C01', 1.000),
(13, 'C03', 'C01', 'C03C01', 1.000),
(14, 'C04', 'C01', 'C04C01', 0.200),
(15, 'C02', 'C02', 'C02C02', 1.000),
(16, 'C03', 'C02', 'C03C02', 0.200),
(17, 'C04', 'C02', 'C04C02', 0.200),
(18, 'C03', 'C03', 'C03C03', 1.000),
(19, 'C04', 'C03', 'C04C03', 0.200),
(20, 'C04', 'C04', 'C04C04', 1.000);

-- --------------------------------------------------------

--
-- Table structure for table `tb_hasil_temp`
--

CREATE TABLE `tb_hasil_temp` (
  `id` int(11) NOT NULL,
  `kode` varchar(225) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `nilai` double NOT NULL,
  `label` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_general_ci;

--
-- Dumping data for table `tb_hasil_temp`
--

INSERT INTO `tb_hasil_temp` (`id`, `kode`, `nama`, `nilai`, `label`) VALUES
(1, 'A01', 'Dayat', 0.148, 'benefit'),
(2, 'A01', 'Dayat', 0.1, 'cost'),
(3, 'A01', 'Dayat', 0.102, 'benefit'),
(4, 'A01', 'Dayat', 0.011, 'benefit'),
(5, 'A02', 'Parman', 0.148, 'benefit'),
(6, 'A02', 'Parman', 0.199, 'cost'),
(7, 'A02', 'Parman', 0.034, 'benefit'),
(8, 'A02', 'Parman', 0.033, 'benefit'),
(9, 'A03', 'Andi', 0.221, 'benefit'),
(10, 'A03', 'Andi', 0.199, 'cost'),
(11, 'A03', 'Andi', 0.102, 'benefit'),
(12, 'A03', 'Andi', 0.044, 'benefit'),
(13, 'A04', 'Sapto', 0.221, 'benefit'),
(14, 'A04', 'Sapto', 0.1, 'cost'),
(15, 'A04', 'Sapto', 0.102, 'benefit'),
(16, 'A04', 'Sapto', 0.011, 'benefit'),
(17, 'A05', 'Rudi', 0.148, 'benefit'),
(18, 'A05', 'Rudi', 0.1, 'cost'),
(19, 'A05', 'Rudi', 0.068, 'benefit'),
(20, 'A05', 'Rudi', 0.044, 'benefit');

-- --------------------------------------------------------

--
-- Table structure for table `tb_history`
--

CREATE TABLE `tb_history` (
  `id_history` int(100) NOT NULL,
  `kode_tiket` varchar(100) NOT NULL,
  `kode_alternatif` varchar(10) NOT NULL,
  `nama_alternatif` varchar(100) NOT NULL,
  `nilai` varchar(10) NOT NULL,
  `tanggal` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_history`
--

INSERT INTO `tb_history` (`id_history`, `kode_tiket`, `kode_alternatif`, `nama_alternatif`, `nilai`, `tanggal`) VALUES
(1, '1811230003', 'A01', 'Dayat', '0.049', '2023-11-18'),
(2, '1811230003', 'A02', 'Parman', '0.016', '2023-11-18'),
(3, '1811230003', 'A03', 'Andi', '0.116', '2023-11-18'),
(4, '1811230003', 'A04', 'Sapto', '0.053', '2023-11-18'),
(5, '1811230003', 'A05', 'Rudi', '0.01', '2023-11-18'),
(6, '1811230004', 'A01', 'Dayat', '0.049', '2023-11-18'),
(7, '1811230004', 'A02', 'Parman', '0.016', '2023-11-18'),
(8, '1811230004', 'A03', 'Andi', '0.116', '2023-11-18'),
(9, '1811230004', 'A04', 'Sapto', '0.053', '2023-11-18'),
(10, '1811230004', 'A05', 'Rudi', '0.01', '2023-11-18'),
(11, '1811230005', 'A01', 'Dayat', '0.049', '2023-11-18'),
(12, '1811230005', 'A02', 'Parman', '0.016', '2023-11-18'),
(13, '1811230005', 'A03', 'Andi', '0.116', '2023-11-18'),
(14, '1811230005', 'A04', 'Sapto', '0.053', '2023-11-18'),
(15, '1811230005', 'A05', 'Rudi', '0.01', '2023-11-18'),
(16, '1811230006', 'A01', 'Dayat', '0.142', '2023-11-18'),
(17, '1811230006', 'A02', 'Parman', '0.201', '2023-11-18'),
(18, '1811230006', 'A03', 'Andi', '0.036', '2023-11-18'),
(19, '1811230006', 'A04', 'Sapto', '-0.027', '2023-11-18'),
(20, '1811230006', 'A05', 'Rudi', '-0.134', '2023-11-18'),
(21, '1811230007', 'A01', 'Dayat', '-0.076', '2023-11-18'),
(22, '1811230007', 'A02', 'Parman', '-0.067', '2023-11-18'),
(23, '1811230007', 'A03', 'Andi', '0.16', '2023-11-18'),
(24, '1811230007', 'A04', 'Sapto', '0.104', '2023-11-18'),
(25, '1811230007', 'A05', 'Rudi', '0.061', '2023-11-18'),
(26, '1811230007', 'A06', 'diendra', '0.114', '2023-11-18'),
(27, '1811230008', 'A01', 'Dayat', '-0.076', '2023-11-18'),
(28, '1811230008', 'A02', 'Parman', '-0.067', '2023-11-18'),
(29, '1811230008', 'A03', 'Andi', '0.16', '2023-11-18'),
(30, '1811230008', 'A04', 'Sapto', '0.104', '2023-11-18'),
(31, '1811230008', 'A05', 'Rudi', '0.061', '2023-11-18'),
(32, '1811230008', 'A06', 'diendra', '0.114', '2023-11-18'),
(33, '1811230009', 'A01', 'Dayat', '0.199', '2023-11-18'),
(34, '1811230009', 'A02', 'Parman', '0.247', '2023-11-18'),
(35, '1811230009', 'A03', 'Andi', '0.083', '2023-11-18'),
(36, '1811230009', 'A04', 'Sapto', '-0.017', '2023-11-18'),
(37, '1811230009', 'A05', 'Rudi', '0.06', '2023-11-18'),
(38, '1811230009', 'A06', 'diendra', '-0.024', '2023-11-18'),
(39, '1811230010', 'A01', 'Dayat', '0.161', '2023-11-18'),
(40, '1811230010', 'A02', 'Parman', '0.016', '2023-11-18'),
(41, '1811230010', 'A03', 'Andi', '0.168', '2023-11-18'),
(42, '1811230010', 'A04', 'Sapto', '0.234', '2023-11-18'),
(43, '1811230010', 'A05', 'Rudi', '0.16', '2023-11-18');

-- --------------------------------------------------------

--
-- Table structure for table `tb_history_temp`
--

CREATE TABLE `tb_history_temp` (
  `id_history` int(100) NOT NULL,
  `kode_tiket` varchar(100) NOT NULL,
  `kode_alternatif` varchar(10) NOT NULL,
  `nama_alternatif` varchar(100) NOT NULL,
  `nilai` varchar(10) NOT NULL,
  `tanggal` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_history_temp`
--

INSERT INTO `tb_history_temp` (`id_history`, `kode_tiket`, `kode_alternatif`, `nama_alternatif`, `nilai`, `tanggal`) VALUES
(1, '1811230010', 'A01', 'Dayat', '0.161', '2023-11-18'),
(2, '1811230010', 'A02', 'Parman', '0.016', '2023-11-18'),
(3, '1811230010', 'A03', 'Andi', '0.168', '2023-11-18'),
(4, '1811230010', 'A04', 'Sapto', '0.234', '2023-11-18'),
(5, '1811230010', 'A05', 'Rudi', '0.16', '2023-11-18');

-- --------------------------------------------------------

--
-- Table structure for table `tb_perbandingan`
--

CREATE TABLE `tb_perbandingan` (
  `id_perbandingan` int(11) NOT NULL,
  `nama_perbandingan` varchar(225) NOT NULL,
  `nilai_perbandingan` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_general_ci;

--
-- Dumping data for table `tb_perbandingan`
--

INSERT INTO `tb_perbandingan` (`id_perbandingan`, `nama_perbandingan`, `nilai_perbandingan`) VALUES
(1, 'Sama penting dengan', 1),
(2, 'Mendekati sedikit lebih penting dari', 2),
(3, 'Sedikit lebih penting dari', 3),
(4, 'Mendekati lebih penting dari', 4),
(5, 'Lebih penting dari', 5),
(6, 'Mendekati sangat penting dari', 6),
(7, 'Sangat penting dari', 7),
(8, 'Mendekati mutlak dari', 8),
(9, 'Mutlak sangat penting dari', 9);

-- --------------------------------------------------------

--
-- Table structure for table `tb_perbandingan_moora`
--

CREATE TABLE `tb_perbandingan_moora` (
  `id_perbandingan` int(11) NOT NULL,
  `nama_banding` varchar(225) NOT NULL,
  `nilai` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_general_ci;

--
-- Dumping data for table `tb_perbandingan_moora`
--

INSERT INTO `tb_perbandingan_moora` (`id_perbandingan`, `nama_banding`, `nilai`) VALUES
(1, 'Sangat Baik', 10),
(2, 'Baik', 20),
(3, 'Cukup Baik', 30),
(4, 'Kurang Baik', 40);

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id_user` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(225) NOT NULL,
  `haka` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_general_ci;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id_user`, `username`, `password`, `haka`) VALUES
(1, 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'Administrator');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_alternatif`
--
ALTER TABLE `tb_alternatif`
  ADD PRIMARY KEY (`id_moora`);

--
-- Indexes for table `tb_data_kriteria`
--
ALTER TABLE `tb_data_kriteria`
  ADD PRIMARY KEY (`id_data_kriteria`);

--
-- Indexes for table `tb_hasil_alternatif`
--
ALTER TABLE `tb_hasil_alternatif`
  ADD PRIMARY KEY (`id_hasil_alternatif`);

--
-- Indexes for table `tb_hasil_kriteria`
--
ALTER TABLE `tb_hasil_kriteria`
  ADD PRIMARY KEY (`id_hasil_kriteria`);

--
-- Indexes for table `tb_hasil_temp`
--
ALTER TABLE `tb_hasil_temp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_history`
--
ALTER TABLE `tb_history`
  ADD PRIMARY KEY (`id_history`);

--
-- Indexes for table `tb_history_temp`
--
ALTER TABLE `tb_history_temp`
  ADD PRIMARY KEY (`id_history`);

--
-- Indexes for table `tb_perbandingan`
--
ALTER TABLE `tb_perbandingan`
  ADD PRIMARY KEY (`id_perbandingan`);

--
-- Indexes for table `tb_perbandingan_moora`
--
ALTER TABLE `tb_perbandingan_moora`
  ADD PRIMARY KEY (`id_perbandingan`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_alternatif`
--
ALTER TABLE `tb_alternatif`
  MODIFY `id_moora` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tb_data_kriteria`
--
ALTER TABLE `tb_data_kriteria`
  MODIFY `id_data_kriteria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tb_hasil_alternatif`
--
ALTER TABLE `tb_hasil_alternatif`
  MODIFY `id_hasil_alternatif` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `tb_hasil_kriteria`
--
ALTER TABLE `tb_hasil_kriteria`
  MODIFY `id_hasil_kriteria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `tb_hasil_temp`
--
ALTER TABLE `tb_hasil_temp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `tb_history`
--
ALTER TABLE `tb_history`
  MODIFY `id_history` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `tb_history_temp`
--
ALTER TABLE `tb_history_temp`
  MODIFY `id_history` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tb_perbandingan`
--
ALTER TABLE `tb_perbandingan`
  MODIFY `id_perbandingan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tb_perbandingan_moora`
--
ALTER TABLE `tb_perbandingan_moora`
  MODIFY `id_perbandingan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
