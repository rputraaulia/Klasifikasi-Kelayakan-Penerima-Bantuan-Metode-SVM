<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Model_data extends CI_Model
{
    public function total_data()
    {
        return $this->db->get('tb_alternatif')->num_rows();
    }
    public function nilai_perbandingan()
    {
        return $this->db->get('tb_perbandingan')->result_array();
    }
    public function nilai_perbandingan1()
    {
        return $this->db->get('tb_perbandingan_moora')->result_array();
    }
    public function get_alternatif()
    {
        return $this->db->get('tb_alternatif')->result_array();
    }


    public function get_kriteria()
    {
        return $this->db->get('tb_data_kriteria')->result_array();
    }
    public function get_tb_hasil_alternatif()
    {
        return $this->db->get('tb_hasil_alternatif')->result_array();
    }
    public function get_tb_hasil_kriteria()
    {
     
        $result_category = $this->db->query("SELECT DISTINCT kode3,perbandingan_id FROM tb_hasil_kriteria ORDER BY `tb_hasil_kriteria`.`kode3` ASC");
      
        return $result_category->result_array();
    }
    public function get_total_hasil_kriteria()
    {
        $result_category = $this->db->query("SELECT DISTINCT kode3,perbandingan_id FROM tb_hasil_kriteria ORDER BY `tb_hasil_kriteria`.`kode2` ASC");
      
        return $result_category->result_array();
    }



    public function get_total_hasil_alternatif()
    {
     
        $result_category = $this->db->query("SELECT * FROM `tb_hasil_alternatif` ORDER BY `tb_hasil_alternatif`.`kode2` ASC");
      
        return $result_category->result_array();
    }
  
    public function tambah_data_alternatif($data)
    {
        $this->db->insert('tb_alternatif', $data);
        return $this->db->affected_rows();
    }
    public function hapus_data_alternatif($id)
    {
        $this->db->delete('tb_alternatif', ['id_moora' => $id]);

        return $this->db->affected_rows();
    }
    public function edit_data_alternatif($id, $data)
    {
        $this->db->update('tb_alternatif', $data, ['id_moora' => $id]);

        return $this->db->affected_rows();
    }
    //user
    public function get_data_alternatif($id)
    {
        $id = $id;
        if ($id == null) {
            return $this->db->get('tb_alternatif')->result_array();
        } else {
            return $this->db->get_where('tb_alternatif', ['id_moora' => $id])->result_array();
        }
    }

    public function get_data_history($id)
    {
        $id = $id;
        if ($id == null) {
            return $this->db->get('tb_history')->result_array();
        } else {
            return $this->db->get_where('tb_histoory', ['id_history' => $id])->result_array();
        }
    }



    
    public function total_data_kriteria()
    {
        return $this->db->get('tb_data_kriteria')->num_rows();
    }

    public function tambah_data_kriteria($data)
    {
        $this->db->insert('tb_data_kriteria', $data);
        return $this->db->affected_rows();
    }
    public function hapus_data_kriteria($id)
    {
        $this->db->delete('tb_data_kriteria', ['id_data_kriteria' => $id]);

        return $this->db->affected_rows();
    }
    public function edit_data_kriteria($id, $data)
    {
        $this->db->update('tb_data_kriteria', $data, ['id_data_kriteria' => $id]);

        return $this->db->affected_rows();
    }
    //user
    public function get_data_kriteria($id)
    {
        $id = $id;
        if ($id == null) {
            return $this->db->get('tb_data_kriteria')->result_array();
        } else {
            return $this->db->get_where('tb_data_kriteria', ['id_data_kriteria' => $id])->result_array();
        }
    }

    public function get_hasil_kriteria()
    {
        $this->db->select('*');
        $this->db->from('tb_hasil_kriteria');
        $this->db->join('tb_perbandingan', 'tb_hasil_kriteria.perbandingan_id = tb_perbandingan.id_perbandingan');
        return $this->db->get()->result_array();
    }
    public function get_hasil_alternatif($id)
    {
        $this->db->select('*');
        $this->db->from('tb_hasil_alternatif');
        $this->db->join('tb_perbandingan', 'tb_hasil_alternatif.perbandingan_id = tb_perbandingan.id_perbandingan');
        $this->db->where('kode0', $id);
        return $this->db->get()->result_array();
    }
    public function tambah_hasil_kriteria($data1, $data2, $data3, $data4, $data5, $data6, $data7, $data8, $data9, $data10)
    {
        $this->db->truncate('tb_hasil_kriteria');

        $this->db->insert('tb_hasil_kriteria', $data1);
        $this->db->insert('tb_hasil_kriteria', $data2);
        $this->db->insert('tb_hasil_kriteria', $data3);
        $this->db->insert('tb_hasil_kriteria', $data4);
        $this->db->insert('tb_hasil_kriteria', $data5);
        $this->db->insert('tb_hasil_kriteria', $data6);
        $this->db->insert('tb_hasil_kriteria', $data7);
        $this->db->insert('tb_hasil_kriteria', $data8);
        $this->db->insert('tb_hasil_kriteria', $data9);
        $this->db->insert('tb_hasil_kriteria', $data10);

        return $this->db->affected_rows();
    }
    public function tambah_hasil_alternatif($id, $data1, $data2, $data3, $data4, $data5, $data6, $data7, $data8, $data9, $data10)
    {
        $this->db->delete('tb_hasil_alternatif', ['kode0' => $id]);

        $this->db->insert('tb_hasil_alternatif', $data1);
        $this->db->insert('tb_hasil_alternatif', $data2);
        $this->db->insert('tb_hasil_alternatif', $data3);
        $this->db->insert('tb_hasil_alternatif', $data4);
        $this->db->insert('tb_hasil_alternatif', $data5);
        $this->db->insert('tb_hasil_alternatif', $data6);
        $this->db->insert('tb_hasil_alternatif', $data7);
        $this->db->insert('tb_hasil_alternatif', $data8);
        $this->db->insert('tb_hasil_alternatif', $data9);
        $this->db->insert('tb_hasil_alternatif', $data10);

        return $this->db->affected_rows();
    }


   


   Public function get_kode_tiket()
   {
        $q = $this->db->query("SELECT MAX(RIGHT(kode_tiket,4)) AS kd_max FROM tb_history WHERE DATE(tanggal)=CURDATE()");
        $kd = "";
        if($q->num_rows()>0){
            foreach($q->result() as $k){
                $tmp = ((int)$k->kd_max)+1;
                $kd = sprintf("%04s", $tmp);
            }
        }else{
            $kd = "0001";
        }
        date_default_timezone_set('Asia/Jakarta');
        return date('dmy').$kd;
    }
 
 






}
