<!-- DATA TABLE-->

<!-- DATA TABLE-->
<section class="p-t-20">
    <div class="container">

        <div class="row">
            <div class="col-md-12">
                <h3 style="color:aliceblue" class="title-5 m-b-35"><?= $class; ?></h3>
                <div class="table-responsive table-responsive-data2">

                <form action="<?= base_url('nilai_kriteria/update_data') ?>" method="post">


<div class="row">
<input type="hidden" name="tiket" value="<?= $tiket ?>" >
<?php foreach ($data_alternatif as $data) : ?>
    <div class="col-md-2">
        <h4 style="color:aliceblue"> DSI <?= $data['nama_alternatif'] ?></h4>
        <input type="hidden" name="dsi[]" value="<?= $data['kode_alternatif'] ?>">
        <input type="hidden" name="kode[]" value="<?= $data['nama_alternatif'] ?>">
        <br>
        <div class="table-data__tool-left" style="color:aliceblue">
            <div class="rs-select2--light rs-select2--xl">
                Kondisi Lampu
                <select style="color:aliceblue" name="c1[]" id="select" class="form-control">
                    <option value=0>------------------------------------------------</option>
                    <?php foreach ($nilai as $data1) : ?>
                        <option style="color:aliceblue" value="<?= $data1['nilai']; ?>"><?= $data1['nilai']; ?>. <?= $data1['nama_banding']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <br>
            <div class="rs-select2--light rs-select2--xl" style="color:aliceblue">
                Kondisi ACCU
                <select style="color:aliceblue" name="c2[]" id="select" class="form-control">
                    
                    <option value=0>------------------------------------------------</option>
                    <?php foreach ($nilai as $data1) : ?>
                        <option style="color:aliceblue" value="<?= $data1['nilai']; ?>"><?= $data1['nilai']; ?>. <?= $data1['nama_banding']; ?></option>
                    <?php endforeach; ?>
                </select>

            </div>
            <br>
            <div class="rs-select2--light rs-select2--xl" style="color:aliceblue">
                Kondisi Solar Cell
                <select style="color:aliceblue" name="c3[]" id="select" class="form-control">
                    
                    <option value=0>------------------------------------------------</option>
                    <?php foreach ($nilai as $data1) : ?>
                        <option style="color:aliceblue" value="<?= $data1['nilai']; ?>"><?= $data1['nilai']; ?>. <?= $data1['nama_banding']; ?></option>
                    <?php endforeach; ?>
                </select>

            </div>
            <br>
            <div class="rs-select2--light rs-select2--xl" style="color:aliceblue">
                Kondisi SunSwitch
                <select style="color:aliceblue" name="c4[]" id="select" class="form-control">
                    <option value=0>------------------------------------------------</option>
                    <?php foreach ($nilai as $data1) : ?>
                        <option style="color:aliceblue" value="<?= $data1['nilai']; ?>"><?= $data1['nilai']; ?>. <?= $data1['nama_banding']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <br>
          
        </div>
    </div>
    <?php endforeach; ?>

    


    <div class="col-md-12">
        <button class="btn btn-success" type="submit">
            <i class="fas fa-loading"> </i> Simpan Data
        </button>
    </div>
</div>

</form>
            </div>
        </div>
        </div>
</section>
<!-- END DATA TABLE-->