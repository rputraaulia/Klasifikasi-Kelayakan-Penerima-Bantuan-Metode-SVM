<!-- DATA TABLE-->
<?php if ($this->uri->segment(1) == 'hasil_keputusan') : ?>
   
<?php else : ?>

<?php endif; ?>
<section>
    <div class="row ">
        <div class="col-12 grid-margin">
            <div class="card">
                <div class="card-body">
                    <?php if ($this->uri->segment(1) == 'hasil_keputusan') : ?>
                      
                 
                        <div class="row m-t-10">
                            <div class="col-md-8">
                                <h2 style="color:aliceblue" style="color:aliceblue" class="title-2 m-b-25">Data Keputusan Berhasil Diinput</h2>
                              
                                <div class="alert alert-success" role="alert">
                                    <h4 class="alert-heading">Proses Selesai!</h4>
                                    <p>Hasil Keputusan Akan Segera Dilaporkan Kepada Admin, Terima Kasih</p>
                                    <hr>
                                </div>
                            </div>
                          
                        </div>
                </div>
            </div>
        </div>

        

                            <?php $id3 = 0;
                            foreach ($data_kriteria as $data2) : ?>
                            <tr>
                            
                            <td><?= $data2['kode_kriteria'] ?></td>

                            <?php $id2 = 0;
                            foreach ($hasil_kriteria as $data3) : ?>
                            <td><?= $data3['perbandingan_id'] ?></td>
                    
                            <div class="d-none"><?= $id2++ ?> </div>    
                            <?php endforeach; ?>  
   
                            </tr>
                            <div class="d-none"><?= $id3++ ?> </div>    
                            <?php endforeach; ?>  
                        
    <?php else : ?>
        <div class="row">
            <div class="col-md-12">
                <h2 style="color:aliceblue" class="title-2 m-b-25">Tabel Perbandingan & Bobot Prioritas Antar Kriteria</h2>
                <div class="table-responsive table--no-card m-b-40">
                    <table class="table table-borderless table-striped table-earning">
                        <thead>
                        <tr>
                        <th>Kode</th>
                        <?php $id1 = 0;
                        foreach ($data_kriteria as $data2) : ?>
                                <th><?= $data2['kode_kriteria'] ?></th>
                        <div class="d-none"><?= $id1++ ?> </div>    
                        <?php endforeach; ?>
                            </tr>
                        </thead>
                        <tbody>
                           

                             <?php $no = -1;
                               
                            foreach ($data_kriteria as $data2) : ?>
                             <div class="d-none"><?= $no++ ?> </div> 
                             <?php endforeach; ?>

                            <?php $id1 = 0;
                                  $id3 = 0;
                            foreach ($data_kriteria as $data2) : ?>
                             <tr>

                            <td><?= $data2['kode_kriteria'] ?></td>
                            <div class="d-none"><?= $id1++ ?> </div> 

                            <?php $id2 = 0;  
                            $sum[$id1] = 0;
                            while($id2 <= $no) : ?>
                            <td><?= $hasil_kriteria[$id3]['perbandingan_id']; ?></td>

                            
                            <div class="d-none"><?=$sum[$id1] += $total_kriteria[$id3]['perbandingan_id']; ?> </div> 
                            <div class="d-none"><?= $id2++ ?> </div> 
                            <div class="d-none"><?= $id3++ ?> </div> 
                            <?php endwhile; ?>

                            </tr>   
                            <?php endforeach; ?>

                            <tr style="background-color:#a7a7a8">
                                <td class="text-white">Total</td>
                            <?php $id5 = 0;
                            while($id5 <= $no) : ?>
                              <div class="d-none"><?= $id5++ ?> </div>
                                <td class="text-white"><?= $tk1 = $sum[$id5] ; ?></td>
                               
                                <?php endwhile; ?>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <h2 style="color:aliceblue" class="title-2 m-b-25">Tabel Normalisasi Matrix dan Bobot Prioritas</h2>
                <div class="table-responsive table--no-card m-b-40">
                    <table class="table table-borderless table-striped table-earning">
                        <thead>
                            <tr>
                                <th>Kode</th>
                                <?php $id1 = 0;
                                foreach ($data_kriteria as $data2) : ?>
                                        <th><?= $data2['kode_kriteria'] ?></th>
                                <div class="d-none"><?= $id1++ ?> </div>    
                                <?php endforeach; ?>
                                <th>Bobot Prioritas</th>
                                </tr>   
                        </thead>
                        <tbody>
                
                        <?php $id1 = 0;
                            $id3 = 0;
                            
                            foreach ($data_kriteria as $data2) : ?>
                             <tr>

                            <td><?= $data2['kode_kriteria'] ?></td>
                            <div class="d-none"><?= $id1++ ?> </div> 

                            <?php $id2 = 0;  
                            $id4 = 1;
                            $bk=0;
                            $sum1=0;
                            $sum2=0;
                            $totalbk[$id1]=0;
                            while($id2 <= $no) : ?>
                          

                            <div class="d-none"><?= $sum1=$sum2; ?> </div> 


                            <td><?= $bk = round($hasil_kriteria[$id3]['perbandingan_id']/$sum[$id4], 4); ?></td>

                            <div class="d-none"><?= $sum2 = $sum1+$bk; ?> </div> 


                            <div class="d-none"><?= $id2++ ?> </div> 
                            <div class="d-none"><?= $id3++ ?> </div> 
                            <div class="d-none"><?= $id4++ ?> </div> 


                            <?php endwhile; ?>
                             <td><?= $totalbk[$id1] += round($sum2/($no+1), 3); ?></td>

                            </tr>   
                            <?php endforeach; ?>
                     
                         
                        </tbody>

                    </table>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <h2 style="color:aliceblue" class="title-2 m-b-25">Tabel Penilaian Alternatif </h2>
                <div class="table-responsive table--no-card m-b-40">
                    <table class="table table-borderless table-striped table-earning">
                        <thead>
                            <tr>
                                <th>Kode</th>
                                <?php $id1 = 0;
                                foreach ($data_kriteria as $data2) : ?>
                                        <th><?= $data2['kode_kriteria'] ?></th>
                                <div class="d-none"><?= $id1++ ?> </div>    
                                <?php endforeach; ?>
                            
                                </tr>  
                              
                            </tr>
                        </thead>
                        <tbody>
                           
                        <?php $no1 = -1;
                               
                               foreach ($data_alternatif as $data3) : ?>
                                <div class="d-none"><?= $no1++ ?> </div> 
                                <?php endforeach; ?>
   
                               <?php $id1 = 0;
                                     $id3 = 0;
                               foreach ($data_alternatif as $data3) : ?>
                                <tr>
   
                               <td><?= $data3['kode_alternatif'] ?></td>
                               <div class="d-none"><?= $id1++ ?> </div> 
   
                               <?php $id2 = 0;  
                               $sumalter[$id1] = 0;
                               while($id2 <= $no) : ?>
                               <td><?= $hasil_alternatif[$id3]['nilai']; ?></td>
   
                               <div class="d-none"><?=$sumalter[$id1] += $total_alternatif[$id3]['nilai']; ?> </div> 
                               <div class="d-none"><?= $id2++ ?> </div> 
                               <div class="d-none"><?= $id3++ ?> </div> 
                               <?php endwhile; ?>
   
                               </tr>   
                               <?php endforeach; ?>
                           

                               
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <h2 style="color:aliceblue" class="title-2 m-b-25">Tabel Matriks Keputusan</h2>
                <div class="table-responsive table--no-card m-b-40">
                    <table class="table table-borderless table-striped table-earning">
                        <thead>
                            <tr>
                            <th>Kode</th>
                                <?php $id1 = 0;
                                foreach ($data_kriteria as $data2) : ?>
                                <th><?= $data2['kode_kriteria'] ?></th>
                                <div class="d-none"><?= $id1++ ?> </div>    
                                <?php endforeach; ?>
                               
                                </tr>   
                         
                        </thead>
                        <tbody>
                            <tr>
                              
                              
                            
                            <?php $id1 = 0;
                            $id3 = 0;
                            
                            foreach ($data_alternatif as $data2) : ?>
                             <tr>

                            <td><?= $data2['kode_alternatif'] ?></td>
                            <div class="d-none"><?= $id1++ ?> </div> 

                            <?php $id2 = 0;  
                            $id4 = 1;
                            $hasilalternatif[$id1]=0;
                            $sum1=0;
                            $sum2=0;
                          
                            while($id2 <= $no) : ?>
                          

                            <div class="d-none"><?= $sum1=$sum2; ?> </div> 


                            <td><?= $hasilalternatif[$id1] = round($hasil_alternatif[$id3]['nilai']/100, 4); ?></td>

                            <div class="d-none"><?= $id2++ ?> </div> 
                            <div class="d-none"><?= $id3++ ?> </div> 
                            <div class="d-none"><?= $id4++ ?> </div> 


                            <?php endwhile; ?>
                         

                            </tr>   
                            <?php endforeach; ?>

                            </tr>
                           


                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <h2 style="color:aliceblue" class="title-2 m-b-25">Tabel Normalisasi atribut</h2>
                <div class="table-responsive table--no-card m-b-40">
                    <table class="table table-borderless table-striped table-earning">
                        <thead>
                            <tr>
                            <th>Kode</th>
                                <?php $id1 = 0;
                                foreach ($data_kriteria as $data2) : ?>
                                <th><?= $data2['kode_kriteria'] ?></th>
                                <div class="d-none"><?= $id1++ ?> </div>    
                                <?php endforeach; ?>
                               
                                </tr>  
                           
                        </thead>
                        <tbody>
                        <?php $no1 = -1;
                               
                               foreach ($data_alternatif as $data2) : ?>
                                <div class="d-none"><?= $no1++ ?> </div> 
                                <?php endforeach; ?>
   
                               <?php $id1 = 0;
                                     $id3 = 0;
                               foreach ($data_alternatif as $data2) : ?>
                            
   
                          
                               <div class="d-none"><?= $id1++ ?> </div> 
   
                               <?php $id2 = 0;  
                               $sum[$id1] = 0;
                               while($id2 <= $no1) : ?>
                               <div class="d-none"><?=$sum[$id1] += $total_alternatif[$id3]['pow']; ?> </div> 
                               <div class="d-none"><?= $id2++ ?> </div> 
                               <div class="d-none"><?= $id3++ ?> </div> 
                               <?php endwhile; ?>
   
                              
                               <?php endforeach; ?>
   
                               <?php $id1 = 0;
                                     $id3 = 0;
                               foreach ($data_alternatif as $data2) : ?>

                               <tr>
                               <td><?= $data2['kode_alternatif'] ?></td>
                               <div class="d-none"><?= $id1++ ?> </div> 

                               <?php $id5 = 0;
                                     $id6=0;
                               while($id5 <= $no) : ?>

                                <div class="d-none"><?= $id5++ ?> </div>
                                <div class="d-none"><?= $tk1 = $sum[$id5] ; ?> </div> 
                                <div class="d-none"><?= $hasilalternatif[$id1] = round($hasil_alternatif[$id3]['nilai']/100, 4); ?> </div> 
                                
                                <td><?= $hasilfinal[$id1]=round(($hasilalternatif[$id1]/sqrt($tk1)), 3);  ?></td>

                                <div class="d-none"><?= $id3++ ?> </div> 


                                   <?php endwhile; ?>

                                   <?php endforeach; ?>
                               </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <h2 style="color:aliceblue" class="title-2 m-b-25">Tabel Optimasi Atribute</h2>
                <div class="table-responsive table--no-card m-b-40">
                    <table class="table table-borderless table-striped table-earning">
                        <thead>
                            <tr>
                            
                                <th>Kode</th>
                                <?php $id1 = 0;
                                foreach ($data_kriteria as $data2) : ?>
                                <th><?= $data2['kode_kriteria'] ?></th>
                                <div class="d-none"><?= $id1++ ?> </div>    
                                <?php endforeach; ?>
                            
                            </tr>
                            <tr>
                                <th style="background-color:#A9A9A9">Label</th>
                                
                                <?php $id1 = 0;
                                foreach ($data_kriteria as $data2) : ?>
                                 <div class="d-none"><?= $id1++ ?> </div>   
                               <th style="background-color:#A9A9A9"><?= $data2['label'] ; ?></th>
                                
                                <?php endforeach; ?>
                                
                            </tr>
                            <tr>
                                <th style="background-color:#4B0082">Nilai Bobot</th>
                                <?php $id1 = 0;
                                foreach ($data_kriteria as $data2) : ?>
                                 <div class="d-none"><?= $id1++ ?> </div>   
                               <th style="background-color:#4B0082"><?= $totalbk[$id1] ; ?></th>
                                
                                <?php endforeach; ?>

                                
                               
                               
                            </tr>
                        </thead>
                        <tbody>
                        <?php $no1 = -1;
                               
                               foreach ($data_alternatif as $data2) : ?>
                                <div class="d-none"><?= $no1++ ?> </div> 
                                <?php endforeach; ?>
   
                               <?php $id1 = 0;
                                     $id3 = 0;
                               foreach ($data_alternatif as $data2) : ?>
                            
   
                          
                               <div class="d-none"><?= $id1++ ?> </div> 
   
                               <?php $id2 = 0;  
                               $sum[$id1] = 0;
                               while($id2 <= $no1) : ?>
                               <div class="d-none"><?=$sum[$id1] += $total_alternatif[$id3]['pow']; ?> </div> 
                               <div class="d-none"><?= $id2++ ?> </div> 
                               <div class="d-none"><?= $id3++ ?> </div> 
                               <?php endwhile; ?>
   
                              
                               <?php endforeach; ?>
   
                               <?php $id1 = 0;
                                     $id3 = 0;
                               $this->db->truncate('tb_hasil_temp');
                               foreach ($data_alternatif as $data2) : ?>

                               <tr>
                               <td><?= $data2['kode_alternatif'] ?></td>
                               <div class="d-none"><?= $id1++ ?> </div> 

                               <?php $id5 = 0;
                                     $id6=0;
                               while($id5 <= $no) : ?>

                                <div class="d-none"><?= $id5++ ?> </div>
                                <div class="d-none"><?= $tk1 = $sum[$id5] ; ?> </div> 
                                <div class="d-none"><?= $hasilalternatif[$id1] = round($hasil_alternatif[$id3]['nilai']/100, 4); ?> </div> 
                                
                                <td><?= $hasilfinal[$id1]=round(($hasilalternatif[$id1]/sqrt($tk1))*$totalbk[$id5], 3);  ?></td>

                                <div class="d-none"><?= $id3++ ?> </div> 
                                <?php
                                $this->load->model('model_data', 'data');
                               
                              
                                $data1 = [
                                    'kode' => $data2['kode_alternatif'],
                                    'nama' => $data2['nama_alternatif'],
                                    'nilai' => $hasilfinal[$id1],
                                    'label' =>$data_kriteria[$id6]['label']
                                   
                                ];
                                $this->db->insert('tb_hasil_temp', $data1);

                                ?>
                                <div class="d-none"><?= $id6++ ?> </div> 
                                   <?php endwhile; ?>

                                   <?php endforeach; ?>
                               </tr>
                          
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <h2 style="color:aliceblue" class="title-2 m-b-25">Tabel Hasil Perhitungan Nilai Prefiks</h2>
                <div class="table-responsive table--no-card m-b-40">
                    <table class="table table-borderless table-striped table-earning">
                        <thead>
                            <tr>
                                <th>Kode</th>
                                <th>Benefit</th>
                                <th>Cost</th>
                                <th>Nilai Prefiks</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $id1 = 0;
                                  $id3 = 0;
                                  $test= "";
                                $this->db->truncate('tb_history_temp');
                               foreach ($data_alternatif as $data2) : ?>
                               <tr>
                               <td><?= $data2['kode_alternatif'] ?></td>
                               <div class="d-none"><?= $kode_keputusan; ?> </div> 
                             
                               <?php 

                               $test=$data_alternatif[$id1]['kode_alternatif'];
                               $benefit = $this->db->query("SELECT sum(nilai) FROM tb_hasil_temp WHERE kode='$test' AND label ='benefit'")->result_array(); 
                               $cost = $this->db->query("SELECT sum(nilai) FROM tb_hasil_temp WHERE kode='$test' AND label ='cost'")->result_array(); 
                               
                               
                               ?>

                               <td><?= $benf= round($benefit[0]['sum(nilai)'],4); ?></td>
                               <td><?= $cost=round($cost[0]['sum(nilai)'],4); ?></td>

                               <td><?= $pref=$benf-$cost; ?></td>
                               <div class="d-none"><?= $id1++ ?> </div> 
                               </tr>
                               <?php
                                $this->load->model('model_data', 'data');
                               
                              
                                $data2 = [
                                    'kode_tiket' => $kode_keputusan,
                                    'kode_alternatif' => $data2['kode_alternatif'],
                                    'nama_alternatif' => $data2['nama_alternatif'],
                                    'nilai' => $pref
                                    
                                   
                                ];
                                $this->db->insert('tb_history', $data2);
                                $this->db->insert('tb_history_temp', $data2);
                                ?>

                               <?php endforeach; ?>
                              
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

       

        <div class="row m-t-10">
            <div class="col-md-9">
                <h2 style="color:aliceblue" class="title-2 m-b-25">Hasil Keputusan</h2>

                <?php $data_ahp = $this->db->query('SELECT * FROM tb_history_temp ORDER BY nilai DESC ')->result_array(); ?>
               
                
                <div class="alert alert-success" role="alert">
                  
                  <p>Berdasarkan perhitungan metode ahp-moora, disimpulkan hasil perangkingan prioritas penerima bantuan
                    seperti seperti disamping<hr>

              </div>
          </div>
          
            

            <div class="col-md-3">
                <h2 style="color:aliceblue" class="title-2 m-b-25">Perangkingan</h2>
                <div class="top-campaign">
                    <div class="table-responsive">
                        <table class="table table-top-campaign">
                            <tbody>
                                <?php $no = 1;
                                foreach ($data_ahp as $data) : ?>
                                   <?php if ($data['nilai']!=0):?>

                                   <tr>
                                        <td><?= $no++; ?>. <?= $data['nama_alternatif'] ?></td>
                                        <td><?= $data['nilai']; ?></td>
                                    </tr>
                                    <?php else : ?>
                                        
                                    <?php endif?>

                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
    </div>
</section>
<!-- END DATA TABLE-->