<!-- WELCOME-->
<section class="welcome p-t-10">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 style="color:aliceblue" class="title-4"><?= $title ?>
                </h1>
                <hr class="line-seprate">
            </div>
        </div>
    </div>
</section>
<!-- END WELCOME-->

<!-- DATA TABLE-->
<section class="p-t-20">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h3 style="color:aliceblue" class="title-5 m-b-35"><?= $class; ?></h3>
                <?php if ($cek == 'edit') : ?>
                    <div class="table-data__tool">
                        <form action="<?= base_url('data_kriteria/edit_data') ?>" method="post">
                            <div class="table-data__tool-left">
                                <div class="rs-select2--light rs-select2--xl">
                                    <input type="text" id="text-input" name="kode" value="<?= $kode_kriteria ?>" class="form-control">
                                </div>
                                <div class="rs-select2--light rs-select2--xl">
                                    <input type="text" id="text-input" name="nama" value="<?= $nama_kriteria ?>" class="form-control">
                                </div>
                                <div class="rs-select2--light rs-select2--xl">
                                    <input type="text" id="text-input" name="label" value="<?= $label ?>" class="form-control">
                                </div>
                                <input type="hidden" id="text-input" name="id" value="<?= $id_data_kriteria ?>" class="form-control">
                                <button class="au-btn au-btn-icon au-btn--green au-btn--small">
                                    <i class="zmdi zmdi-plus"></i>Edit Data</button>
                            </div>
                        </form>
                    </div>
                <?php elseif ($batas == '10') : ?>

                <?php else : ?>
                    <div class="table-data__tool">
                        <form action="<?= base_url('data_kriteria/tambah_data') ?>" method="post">
                            <div class="table-data__tool-left">
                                <div class="rs-select2--light rs-select2--xl">
                                    <input type="text" id="text-input" name="kode" placeholder="Kode Kriteria" class="form-control">
                                </div>
                                <div class="rs-select2--light rs-select2--xl">
                                    <input type="text" id="text-input" name="nama" placeholder="Nama Kriteria" class="form-control">
                                </div>
                                <div class="rs-select2--light rs-select2--xl">
                                    <input type="text" id="text-input" name="label" placeholder="Label Kriteria" class="form-control">
                                </div>
                                <button class="au-btn au-btn-icon au-btn--green au-btn--small">
                                        <i class="zmdi zmdi-plus"></i>Tambah Data</button>
                            </div>
                        </form>

                    </div>
                <?php endif; ?>
                <div class="table-responsive table-responsive-data2">
                    <table class="table table-data2">
                        <thead>
                            <tr>
                                <th style="color:aliceblue">No.</th>
                                <th style="color:aliceblue">Kode</th>
                                <th style="color:aliceblue">Nama Kriteria</th>
                                <th style="color:aliceblue">Label</th>
                                <th style="color:aliceblue">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 1;
                            foreach ($data_kriteria as $data) : ?>
                                <tr class="tr-shadow">
                                    <td><?= $no++; ?></td>
                                    <td>
                                        <span class="block-email"><?= $data['kode_kriteria']; ?></span>
                                    </td>
                                    <td><?= $data['nama_kriteria']; ?></td>
                                    <td><?= $data['label']; ?></td>
                                    <td style="text-align: left">
                                        <div class="table-data-feature">
                                            <a href="<?= base_url('data_kriteria/index/' . $data['id_data_kriteria']) ?>" class="item" title="Edit">
                                                <i class="zmdi zmdi-edit"></i>
                                            </a>
                                            <a href="<?= base_url('data_kriteria/hapus_data/' . $data['id_data_kriteria']) ?>" class="item" title="Delete">
                                                <i class="zmdi zmdi-delete"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <tr class="spacer"></tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- END DATA TABLE-->