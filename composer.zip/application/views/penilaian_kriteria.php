<section>
    <div class="row ">
        <div class="col-12 grid-margin">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Penilaian Kepentingan Kriteria</h4>


                    <form action="<?= base_url('penilaian_kriteria/simpan_penilaian') ?>" method="post">

                        <table class="table table-data2">
                            <thead>
                                <tr class="text-center">
                                    <th style="color:aliceblue">Nama Kriteria</th>
                                    <th style="color:aliceblue">Nilai Perbandingan</th>
                                    <th style="color:aliceblue">Nama Kriteria</th>
                                </tr>
                            </thead>
                            <tbody>

                            <?php $no = 1;
                            foreach ($data_kriteria as $data) : ?>
                            <div class="d-none"><?= $no++ ?> </div>
                            <?php endforeach; ?>

                            <?php
                                $id1 = 0;
                                $id5 = 0;
                                $id7 = 0;
                                $id4=2;
                                $total=$no-1;
                                while($id1 <= $no) : ?>


                                <?php
                                
                                $id2 = $id5;
                                $id3 = 0;
                                $total=$no-$id4; 
                                $id6 =0;    
                                while($id6 <= $total) : ?>
                                <tr class="tr-shadow text-center">
                                
                                    <td> <?= $data_kriteria[$id1]['kode_kriteria']; ?> - <?= $data_kriteria[$id1]['nama_kriteria']; ?> </td>
                                    <input type="hidden" name="kode1[]" value="<?= $data_kriteria[$id1]['kode_kriteria']; ?>">
                                    <input type="hidden" name="kode2[]" value="<?= $data_kriteria[$id2]['kode_kriteria']; ?>">
                                    <td>

                                        <select style="color:aliceblue" name="perbandingan[]" id="select" class="form-control">
                                            <option value="<?= $hasil_kriteria[$id7]['perbandingan_id']; ?>"><?= $hasil_kriteria[$id7]['perbandingan_id']; ?>. <?= $hasil_kriteria[$id7]['nama_perbandingan']; ?></option>
                                            <option>---------------------------------------------------</option>
                                            <?php foreach ($nilai_perbandingan as $data) : ?>
                                                <option value="<?= $data['id_perbandingan'] ?>"><?= $data['nilai_perbandingan']; ?>. <?= $data['nama_perbandingan']; ?></option>
                                            <?php endforeach; ?>
                                        </select>

                                    </td>
                                    <td><?= $data_kriteria[$id2]['kode_kriteria']; ?> - <?= $data_kriteria[$id2]['nama_kriteria']; ?></td>
                                </tr>
                                <tr class="spacer"></tr>
                                <div class="d-none"><?= $id2++ ?> </div>
                                <div class="d-none"><?= $id6++ ?> </div>
                                <div class="d-none"><?= $id7++ ?> </div>
                                <?php endwhile; ?>

                                <div class="d-none"><?= $id1++ ?> </div>
                                <div class="d-none"><?= $id4++ ?> </div>
                                <div class="d-none"><?= $id5++ ?> </div>
                             
                                <?php endwhile; ?>



                            </tbody>
                        </table>
                        <div class="col-md-12">
                            <button class="btn btn-success" type="submit">
                                <i class="fas fa-loading"> </i> Simpan
                            </button>
                        </div>
                </div>


                </div>
            </div>
        </div>
    </div>
    
</section>