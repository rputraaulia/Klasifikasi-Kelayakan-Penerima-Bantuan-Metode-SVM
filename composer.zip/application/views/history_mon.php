<section class="welcome p-t-10">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 style="color:aliceblue" class="title-4"><?= $title ?>
                </h1>
                <hr class="line-seprate">
            </div>
        </div>
    </div>
	</section>
<?php $data_ahp = $this->db->query('SELECT * FROM `tb_history`')->result_array(); ?>

<section class="p-t-20">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
		<div class="table-responsive">
		<table class="table table-bordered">
			<thead>
				<tr>
					<th>Kode Putusan</th>
					<th>Nama</th>
					<th>Nilai</th>
				    <th>Tanggal</th>
				</tr>
			</thead>


			<tbody>
            <?php $no = 1;
     foreach ($data_ahp as $data) : ?>
            <tr>
            <td style="color:aliceblue"><?= $data['kode_tiket']; ?> </td>
             <td style="color:aliceblue"><?= $data['nama_alternatif']; ?></td>
             <td style="color:aliceblue"><?= $data['nilai']; ?> </td>
                      
             <td style="color:aliceblue"><?= $data['tanggal']; ?></td>
              
            </tr>
              <?php endforeach; ?>
				
			</tbody>
		</table>
	</div>
	</div>
            </div>
        </div>
    </div>
</section>