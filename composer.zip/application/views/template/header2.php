<nav class="sidebar sidebar-offcanvas" id="sidebar">
            <div class="sidebar-brand-wrapper d-none d-lg-flex align-items-center justify-content-center fixed-top">
                <a class="sidebar-brand brand-logo" href="">
                    <h4 style="color:aliceblue"> Sistem Pencarian Keputusan</h4>
                </a>
                <a class="sidebar-brand brand-logo-mini" href="">
                    <h4> Sistem Pencarian Keputusan</h4>
                </a>
                          </div>
                          


<ul class="nav">
         

          <li class="nav-item nav-category">
            <span class="nav-link">Menu</span>
          </li>
          
          <li class="nav-item menu-items">
            <a class="nav-link" href="<?= base_url('data_alternatif') ?>">
            <span class="menu-icon">
                <i class="mdi mdi mdi-castle "></i>
              </span>
              <span class="menu-title">Data Alternatif</span>
            </a>
          </li>
          <li class="nav-item menu-items">
            <a class="nav-link" href="<?= base_url('data_kriteria') ?>">
            <span class="menu-icon">
                <i class="mdi mdi mdi-castle "></i>
              </span>
              <span class="menu-title">Data Kriteria</span>
            </a>
          </li>
          <li class="nav-item menu-items">
            <a class="nav-link" href="<?= base_url('penilaian_kriteria') ?>">
            <span class="menu-icon">
                <i class="mdi mdi-image-filter-frames"></i>
              </span>
              <span class="menu-title">Penilaian Kriteria</span>
            </a>
          </li>
          <li class="nav-item menu-items">
            <a class="nav-link" href="<?= base_url('penilaian_alternatif') ?>">
              <span class="menu-icon">
                <i class="mdi mdi-book"></i>
              </span>
              <span class="menu-title">Pencarian Keputusan</span>
            </a>
          </li>
          <li class="nav-item menu-items">
            <a class="nav-link" href="<?= base_url('history_mon') ?>">
              <span class="menu-icon">
                <i class="mdi mdi-security"></i>
              </span>
              <span class="menu-title">History</span>
            </a>
          </li>


          <li class="nav-item menu-items">
            <a class="nav-link" href="<?= base_url('login/logout') ?>">
              <span class="menu-icon">
                <i class="mdi mdi-account-key"></i>
              </span>
              <span class="menu-title">Logout Admin</span>
            </a>
          </li>
        </ul>

  </nav>
