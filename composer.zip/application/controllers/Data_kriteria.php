<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Data_kriteria extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		#notifikasi
		$this->load->model('model_data', 'data');
		
	}
	public function index($id = null)
	{
		$session['hasil'] = $this->session->userdata('logged_in');
		$role = $session['hasil']->haka;
		$d['haka'] = $role;

		$d['title']="Setting Data";
		$d['class']="Data Kriteria";
		$d['konten']="data_kriteria";

		$d['batas'] = $this->data->total_data_kriteria();
		$d['data_kriteria'] = $this->data->get_data_kriteria('');

		if($id != null)
		{
			$d['cek'] = "edit";
			$data_kriteria_id = $this->data->get_data_kriteria($id);
			$d['kode_kriteria'] = $data_kriteria_id[0]['kode_kriteria'];
			$d['nama_kriteria'] = $data_kriteria_id[0]['nama_kriteria'];
			$d['label'] = $data_kriteria_id[0]['label'];
			$d['id_data_kriteria'] = $data_kriteria_id[0]['id_data_kriteria'];

		}else{
			$d['cek'] = "no";
		}

		#Keamanan Login Session dan hak ases akun
		if ($this->session->userdata('logged_in') and $role == 'Administrator') {
			$this->load->view('template/home', $d);
		} else {
			$this->session->set_flashdata('pesan', 'statusoff');
			redirect('login/kick');
		}
	}
	public function tambah_data()
	{
		$data = [
			'kode_kriteria' => $this->input->post('kode'),
			'nama_kriteria' => $this->input->post('nama'),
			'label' => $this->input->post('label')
		];

		// var_dump($data);

		if ($hasil = $this->data->tambah_data_kriteria($data) > 0) {
			$this->session->set_flashdata('pesan', 'berhasil');
			redirect('data_kriteria');
		} else {
			$this->session->set_flashdata('pesan', 'gagal');
			redirect('data_kriteria');
		}
	}
	public function edit_data()
	{
		$data = [
			'kode_kriteria' => $this->input->post('kode'),
			'nama_kriteria' => $this->input->post('nama'),
			'label' => $this->input->post('label')
		];
		$id = $this->input->post('id');
		// var_dump($data);

		if ($hasil = $this->data->edit_data_kriteria($id,$data) > 0) {
			$this->session->set_flashdata('pesan', 'rubah');
			redirect('data_kriteria');
		} else {
			$this->session->set_flashdata('pesan', 'gagal');
			redirect('data_kriteria');
		}
	}
	public function hapus_data($id)
	{
		
		$id = $id;
		// var_dump($data);

		if ($hasil = $this->data->hapus_data_kriteria($id) > 0) {
			$this->session->set_flashdata('pesan', 'delete');
			redirect('data_kriteria');
		} else {
			$this->session->set_flashdata('pesan', 'gagal');
			redirect('data_kriteria');
		}
	}
}
