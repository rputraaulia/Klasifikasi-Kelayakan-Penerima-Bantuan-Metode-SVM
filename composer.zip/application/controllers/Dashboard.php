<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		#notifikasi
		$this->load->model('model_data', 'data');
	}
	public function index($id = null)
	{

        $session['hasil'] = $this->session->userdata('logged_in');
        $role = $session['hasil']->haka;
        $d['haka'] = $role;
        $d['konten'] = "dashboard";
      
		$d['title'] = "Sistem Pendukung Keputusan Pemilihan Peneria Bantuan Sosial ";
		$d['class'] = "halaman_utama";




#Keamanan Login Session dan hak ases akun
if ($this->session->userdata('logged_in') and $role == 'Administrator') {
    $this->load->view('template/home', $d);
} else {
   
    redirect('login/kick');

	}
}
}