<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Data_analisa extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		#notifikasi
		$this->load->model('model_data', 'data');
	}
	public function index($id = null)
	{
		$session['hasil'] = $this->session->userdata('logged_in');
		$role = $session['hasil']->haka;
		$d['haka'] = $role;

		$d['title'] = "Analisa";
		$d['class'] = "Proses Pencarian Keputusan";
		$d['konten'] = "data_analisa";

	
		$d['data_kriteria'] = $this->data->get_data_kriteria('');
		$d['data_alternatif'] = $this->data->get_alternatif('');

		$d['hasil_kriteria'] = $this->data->get_tb_hasil_kriteria();
		$d['total_kriteria'] = $this->data->get_total_hasil_kriteria();

		$d['hasil_alternatif'] = $this->data->get_tb_hasil_alternatif();
		$d['total_alternatif'] = $this->data->get_total_hasil_alternatif();
		$d['kode_keputusan'] = $this->data->get_kode_tiket();

		
		#Keamanan Login Session dan hak ases akun
		if ($this->session->userdata('logged_in') and $role == 'Administrator') {
			$this->load->view('template/home', $d);
		} else {
			$this->session->set_flashdata('pesan', 'statusoff');
			redirect('login/kick');
		}
	}
}
