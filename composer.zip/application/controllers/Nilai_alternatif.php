<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Nilai_alternatif extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		#notifikasi
		$this->load->model('model_data', 'data');
		
	}
	public function index($id = null)
	{
		$session['hasil'] = $this->session->userdata('logged_in');
		$role = $session['hasil']->haka;
		$d['haka'] = $role;

		$d['title']="Analisa";
		$d['class']="Nilai Alternatif";
		$d['konten']="nilai_alternatif";

		// $d['batas'] = $this->data->total_data_alternatif();

		
		$d['data_alternatif'] = $this->data->get_data_alternatif('');
		$d['data_kriteria'] = $this->data->get_data_kriteria('');
		
		$d['nilai_perbandingan'] = $this->data->nilai_perbandingan();

		if($id == null)
		{
			$d['id_kriteria'] = $id;
		}else{
			$kriteria = $this->data->get_data_kriteria($id);
			$d['id_kriteria'] = $kriteria[0]['id_data_kriteria'];
			$d['nama_kriteria'] = $kriteria[0]['nama_kriteria'];
			$d['kode_kriteria'] = $kriteria[0]['kode_kriteria'];
			$d['hasil_alternatif'] = $this->data->get_hasil_alternatif($d['kode_kriteria']);
		}
		#Keamanan Login Session dan hak ases akun
		if ($this->session->userdata('logged_in') and $role == 'Administrator') {
			$this->load->view('template/home', $d);
		} else {
			$this->session->set_flashdata('pesan', 'statusoff');
			redirect('login/kick');
		}
	}
	public function tambah_data()
	{
		$data1 = [
			'kode0' => $this->input->post('kode_kriteria'),
			'kode1' => $this->input->post('kode1_0'),
			'kode2' => $this->input->post('kode2_1'),
			'perbandingan_id' => $this->input->post('perbandingan_id1')
		];
		$data2 = [
			'kode0' => $this->input->post('kode_kriteria'),
			'kode1' => $this->input->post('kode1_0'),
			'kode2' => $this->input->post('kode2_2'),
			'perbandingan_id' => $this->input->post('perbandingan_id2')
		];
		$data3 = [
			'kode0' => $this->input->post('kode_kriteria'),
			'kode1' => $this->input->post('kode1_0'),
			'kode2' => $this->input->post('kode2_3'),
			'perbandingan_id' => $this->input->post('perbandingan_id3')
		];
		$data4 = [
			'kode0' => $this->input->post('kode_kriteria'),
			'kode1' => $this->input->post('kode1_0'),
			'kode2' => $this->input->post('kode2_4'),
			'perbandingan_id' => $this->input->post('perbandingan_id4')
		];
		$data5 = [
			'kode0' => $this->input->post('kode_kriteria'),
			'kode1' => $this->input->post('kode1_1'),
			'kode2' => $this->input->post('kode2_22'),
			'perbandingan_id' => $this->input->post('perbandingan_id5')
		];
		$data6 = [
			'kode0' => $this->input->post('kode_kriteria'),
			'kode1' => $this->input->post('kode1_1'),
			'kode2' => $this->input->post('kode2_23'),
			'perbandingan_id' => $this->input->post('perbandingan_id6')
		];
		$data7 = [
			'kode0' => $this->input->post('kode_kriteria'),
			'kode1' => $this->input->post('kode1_1'),
			'kode2' => $this->input->post('kode2_24'),
			'perbandingan_id' => $this->input->post('perbandingan_id7')
		];
		$data8 = [
			'kode0' => $this->input->post('kode_kriteria'),
			'kode1' => $this->input->post('kode1_2'),
			'kode2' => $this->input->post('kode2_33'),
			'perbandingan_id' => $this->input->post('perbandingan_id8')
		];
		$data9 = [
			'kode0' => $this->input->post('kode_kriteria'),
			'kode1' => $this->input->post('kode1_2'),
			'kode2' => $this->input->post('kode2_34'),
			'perbandingan_id' => $this->input->post('perbandingan_id9')
		];
		$data10 = [
			'kode0' => $this->input->post('kode_kriteria'),
			'kode1' => $this->input->post('kode1_3'),
			'kode2' => $this->input->post('kode2_44'),
			'perbandingan_id' => $this->input->post('perbandingan_id10')
		];
		$id = $this->input->post('kode_kriteria');

		if ($hasil = $this->data->tambah_hasil_alternatif($id,$data1,$data2,$data3,$data4,$data5,$data6,$data7,$data8,$data9,$data10) > 0) {
			$this->session->set_flashdata('pesan', 'berhasil');
			redirect('nilai_alternatif');
		} else {
			$this->session->set_flashdata('pesan', 'gagal');
			redirect('nilai_alternatif');
		}
	}
}
