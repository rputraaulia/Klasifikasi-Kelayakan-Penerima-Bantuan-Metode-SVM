<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Landingpage extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		#notifikasi
		$this->load->model('model_data', 'data');
	}
	public function index($id = null)
	{

		$d['title'] = "Sistem Pencarian Keputusan Sarana Distrik Navigasi Kelas II Semarang";
		$d['class'] = "halaman_utama";






		$this->load->view('landingpage', $d);
	}
}
