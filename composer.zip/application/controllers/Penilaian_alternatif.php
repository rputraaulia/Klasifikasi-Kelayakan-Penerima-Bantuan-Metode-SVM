<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Penilaian_alternatif extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		#notifikasi
		$this->load->model('model_data', 'data');
	}
	public function index($id = null)
	{

		$d['title'] = "Analisa";
		$d['class'] = "Input Penilaian Penduduk";
		$d['konten'] = "Penilaian_alternatif";

		$d['batas'] = $this->data->total_data_kriteria();
		$d['data_kriteria'] = $this->data->get_kriteria('');
		$d['hasil_kriteria'] = $this->data->get_hasil_kriteria();
		$d['nilai_perbandingan'] = $this->data->nilai_perbandingan();
		$d['nilai'] = $this->data->nilai_perbandingan1();
        $d['data_alternatif'] = $this->data->get_alternatif('');
        $d['tiket'] = $this->data->get_kode_tiket('');

		
  


		$this->load->view('template/home', $d);
	}
	public function update_data()
    {
     
        $mod1 = $this->input->post('kode1');
		$mod2 = $this->input->post('kode2');
		$mod3 = $this->input->post('nilai');
		
   
		for($i = 0; $i < count($mod1); $i++){

		

		$entries[] = array(

		
		'kode1' => $mod1[$i],
		'kode2' => $mod2[$i],
		'kode3' => $mod2[$i].$mod1[$i],
		'nilai' => $mod3[$i],
		'pow' => pow(($mod3[$i]/100), 2)
				
			);
			
							}	
		

	$this->db->truncate('tb_hasil_alternatif');
	$this->db->insert_batch('tb_hasil_alternatif',  $entries); 

        $this->session->set_flashdata('pesan', 'berhasil');
        redirect('data_analisa');
    
}

}
