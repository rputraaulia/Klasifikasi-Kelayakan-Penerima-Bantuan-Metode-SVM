<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Data_alternatif extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		#notifikasi
		$this->load->model('model_data', 'data');
	}
	public function index($id = null)
	{
		$session['hasil'] = $this->session->userdata('logged_in');
		$role = $session['hasil']->haka;
		$d['haka'] = $role;

		$d['title'] = "Setting Data";
		$d['class'] = "Data Penduduk";
		$d['konten'] = "data_alternatif";

		$d['batas'] = $this->data->total_data();
		$d['data_alternatif'] = $this->data->get_data_alternatif('');

		if ($id != null) {
			$d['cek'] = "edit";
			$data_alternatif_id = $this->data->get_data_alternatif($id);
			$d['kode_alternatif'] = $data_alternatif_id[0]['kode_alternatif'];
			$d['nama_alternatif'] = $data_alternatif_id[0]['nama_alternatif'];
			$d['id_moora'] = $data_alternatif_id[0]['id_moora'];
		} else {
			$d['cek'] = "no";
		}

		#Keamanan Login Session dan hak ases akun
		if ($this->session->userdata('logged_in') and $role == 'Administrator') {
			$this->load->view('template/home', $d);
		} else {
			$this->session->set_flashdata('pesan', 'statusoff');
			redirect('login/kick');
		}
	}
	public function tambah_data()
	{
		$data = [
			'kode_alternatif' => $this->input->post('kode'),
			'nama_alternatif' => $this->input->post('nama')
		];

		// var_dump($data);

		if ($hasil = $this->data->tambah_data_alternatif($data) > 0) {
			$this->session->set_flashdata('pesan', 'berhasil');
			redirect('data_alternatif');
		} else {
			$this->session->set_flashdata('pesan', 'gagal');
			redirect('data_alternatif');
		}
	}
	public function edit_data()
	{
		$data = [
			'kode_alternatif' => $this->input->post('kode'),
			'nama_alternatif' => $this->input->post('nama')
		];
		$id = $this->input->post('id');
		// var_dump($data);

		if ($hasil = $this->data->edit_data_alternatif($id, $data) > 0) {
			$this->session->set_flashdata('pesan', 'rubah');
			redirect('data_alternatif');
		} else {
			$this->session->set_flashdata('pesan', 'gagal');
			redirect('data_alternatif');
		}
	}
	public function hapus_data($id)
	{

		$id = $id;
		// var_dump($data);

		if ($hasil = $this->data->hapus_data_alternatif($id) > 0) {
			
			$this->session->set_flashdata('pesan', 'delete');
			redirect('data_alternatif');
		} else {
			$this->session->set_flashdata('pesan', 'gagal');
			redirect('data_alternatif');
		}
	}
}
