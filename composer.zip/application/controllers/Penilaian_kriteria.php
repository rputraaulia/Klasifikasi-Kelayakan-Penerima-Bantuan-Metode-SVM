<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Penilaian_kriteria extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        #notifikasi
        $this->load->model('model_data', 'data');
    }
    public function index($id = null)
    {
        $session['hasil'] = $this->session->userdata('logged_in');
        $role = $session['hasil']->haka;
        $d['haka'] = $role;

        $d['title'] = "Monitoring Sarana";
        $d['class'] = "Input Monitoring";
        $d['konten'] = "penilaian_kriteria";


        $d['batas'] = $this->data->total_data_kriteria();
		$d['data_kriteria'] = $this->data->get_data_kriteria('');
		$d['hasil_kriteria'] = $this->data->get_hasil_kriteria();
		$d['nilai_perbandingan'] = $this->data->nilai_perbandingan();
		$d['nilai'] = $this->data->nilai_perbandingan1();
     
		
		if ($id != null) {
			$d['cek'] = "edit";
			$data_kriteria_id = $this->data->get_data_kriteria($id);
			$d['kode_kriteria'] = $data_kriteria_id[0]['kode_kriteria'];
			$d['nama_kriteria'] = $data_kriteria_id[0]['nama_kriteria'];
			$d['id_data_kriteria'] = $data_kriteria_id[0]['id_data_kriteria'];
		} else {
			$d['cek'] = "no";
		}


        #Keamanan Login Session dan hak ases akun
        if ($this->session->userdata('logged_in') and $role == 'Administrator') {
            $this->load->view('template/home', $d);
        } else {
            $this->session->set_flashdata('pesan', 'statusoff');
            redirect('login/kick');
        }
    }
   
	public function simpan_penilaian()
	{
		$mod1 = $this->input->post('kode1');
		$mod2 = $this->input->post('kode2');
		$mod3 = $this->input->post('perbandingan');
	
   
		for($i = 0; $i < count($mod1); $i++){

		$entries[] = array(

		
		'kode1' => $mod1[$i],
		'kode2' => $mod2[$i],
		'kode3' => $mod1[$i].$mod2[$i],
		'perbandingan_id' => $mod3[$i]
			  
			);
		$entries2[] = array(

		
		'kode1' => $mod2[$i],
		'kode2' => $mod1[$i],
		'kode3' => $mod2[$i].$mod1[$i],
		'perbandingan_id' => 1/$mod3[$i]
					  
			);
					}	

			
	$this->db->truncate('tb_hasil_kriteria');
	$this->db->insert_batch('tb_hasil_kriteria',  $entries); 
	$this->db->insert_batch('tb_hasil_kriteria',  $entries2); 

	$this->session->set_flashdata('pesan', 'berhasil');
	redirect('penilaian_kriteria');


	}

    
}
